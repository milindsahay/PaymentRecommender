package com.paymentrecommendation.enums;

public enum LineOfBusiness {
    CREDIT_CARD_BILL_PAYMENT,
    COMMERCE,
    INVESTMENT
}
