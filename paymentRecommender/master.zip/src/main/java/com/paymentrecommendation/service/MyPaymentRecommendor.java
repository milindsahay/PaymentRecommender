package com.paymentrecommendation.service;

import com.paymentrecommendation.models.Cart;
import com.paymentrecommendation.models.PaymentInstrument;
import com.paymentrecommendation.models.User;
import com.paymentrecommendation.service.filter.PiFilter;
import com.paymentrecommendation.service.validator.CartValidatorService;

import java.util.ArrayList;
import java.util.List;

public class MyPaymentRecommendor implements PaymentRecommender {
    private PiFilter piFilter;
    private CartValidatorService cartValidatorService;
    MyPaymentRecommendor(){
        this.piFilter = new PiFilter();
        this.cartValidatorService = new CartValidatorService();
    }
    public List<PaymentInstrument> recommendPaymentInstruments(final User user, final Cart cart){
        //validate cart
        if(cartValidatorService.validateCart(cart)) {

            //should be part of user service
            List<PaymentInstrument> paymentInstruments =
                    piFilter.filterOnCustomerCapability(user, user.getUserPaymentInstrument().getPaymentInstruments());

            paymentInstruments =
                    piFilter.filterOnLineOfBusiness(cart, paymentInstruments);

            paymentInstruments =
                    piFilter.filterOnCartAmount(cart, paymentInstruments);

            return piFilter.sortPaymentInstrument(cart.getLineOfBusiness(), paymentInstruments);
        }

        return new ArrayList<>();
    };
}